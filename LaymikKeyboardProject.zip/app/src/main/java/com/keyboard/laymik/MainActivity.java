package com.keyboard.laymik;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        final EditText etPrice = (EditText) findViewById(R.id.etPrice);
        final EditText etCount = (EditText) findViewById(R.id.etCount);
        Button btnOrder = (Button) findViewById(R.id.btnOrder);

        btnOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String price = etPrice.getText().toString();
                String count = etCount.getText().toString();
                Toast.makeText(getApplicationContext(), "Цена: " + price + ", Штук: " + count, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
